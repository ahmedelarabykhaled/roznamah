<?php $__env->startSection('content'); ?>


<div class="text-center mt-5">

    <a href="<?php echo e(url()->previous()); ?>" style="float: right; margin-right: 20px;" class="btn btn-primary">&rarr;</a>
    <h1 class="d-inline-flex"><?php echo e($subcategory->name); ?></h1>
</div>
<section class="container">
    <div class="shadow-sm p-3 mb-3 bg-white rounded my-4" style="font-size: 1.2rem">
    	<?php echo $subcategory->content; ?>

    </div>
<div id="disqus_thread"></div>
</section>




<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>


<script>

/**
*  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
*  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables*/

var disqus_config = function () {
this.page.url = "<?php echo e(url()->current()); ?>";  // Replace PAGE_URL with your page's canonical URL variable
this.page.identifier = "<?php echo e($subcategory->id); ?>" ; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
};

(function() { // DON'T EDIT BELOW THIS LINE
var d = document, s = d.createElement('script');
s.src = 'https://roznamah.disqus.com/embed.js';
s.setAttribute('data-timestamp', +new Date());
(d.head || d.body).appendChild(s);
})();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/roznamah/resources/views/user/subcategory.blade.php ENDPATH**/ ?>