<?php $__env->startSection('content'); ?>
<style type="text/css">
	a
	{
		color: #000;
	}
	a:hover
	{
		color: #000;
		text-decoration: underline;
	}
</style>
<section>
    <div class="text-center mt-5">

        <a href="<?php echo e(url('/')); ?>" style="float: right; margin-right: 20px;" class="btn btn-primary">&rarr;</a>
        <h1 class="d-inline-flex"><?php echo e($category->name); ?></h1>

    </div>
    <div class="my-4 container">
            <div class="text-white">
                <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url('subcategory',$category->id)); ?>" style="color: #fff;" class="d-block shadow-sm p-3 mb-3 bg-primary rounded"># <?php echo e($category->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/roznamah/resources/views/user/category.blade.php ENDPATH**/ ?>