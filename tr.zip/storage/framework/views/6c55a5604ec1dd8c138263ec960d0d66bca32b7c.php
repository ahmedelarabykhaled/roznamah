<?php $__env->startSection('content'); ?>

<div class="text-center mt-5">

    <a href="<?php echo e($date->previousPageUrl()); ?>" style="float: right; margin-right: 20px;" class="btn btn-primary">&rarr;</a>
    <h1 class="d-inline-flex"><?php echo e($date->items()[0]->date); ?></h1>
    <a href="<?php echo e($date->nextPageUrl()); ?>" style="float: left; margin-left: 20px;" class="btn btn-primary">&larr;</a>

    <h3 class=" text-muted "><?php echo e($date->items()[0]->season); ?></h3>
</div>
<div class="container mb-5">
    <!--    <div class="shadow p-3 mb-5 bg-white rounded">Regular shadow</div>-->

    <div id="accordion">
        <div data-toggle="collapse" data-target="#collapse-0" class="shadow-sm p-3 mb-3 bg-white rounded">
            <h4 class="border-bottom pb-2">
                يوم
                <div class="badge badge-primary float-left"><?php echo e($date->items()[0]->day->number); ?></div>
            </h5>
            <div id="collapse-0" class="collapse show" data-parent="#accordion">
                <div class="row">
                    <div class="col-6 font-weight-bold">من</div>
                    <div class="col-6 text-left"><?php echo e($date->items()[0]->day->from); ?></div>
                    <div class="col-6 font-weight-bold">المدة</div>
                    <div class="col-6 text-left"><?php echo e($date->items()[0]->day->duration); ?></div>
                </div>
            </div>
        </div>
        <div data-toggle="collapse" data-target="#collapse-1" class="shadow-sm p-3 mb-3 bg-white rounded">
            <h4 class="border-bottom pb-2">
                الدر
                <div class="badge badge-primary float-left"><?php echo e($date->items()[0]->aldor->number); ?></div>
            </h5>
            <div id="collapse-1" class="collapse show" data-parent="#accordion">
                <div class="row">
                    <div class="col-6 font-weight-bold">من</div>
                    <div class="col-6 text-left"><?php echo e($date->items()[0]->day->from); ?></div>
                    <div class="col-6 font-weight-bold">المدة</div>
                    <div class="col-6 text-left"><?php echo e($date->items()[0]->day->duration); ?></div>
                </div>
            </div>
        </div>
        <div data-toggle="collapse" data-target="#collapse-2" class="shadow-sm p-3 mb-3 bg-white rounded">
            <h4 class="border-bottom pb-2">
                النجم
                <div class="badge badge-primary float-left"><?php echo e($date->items()[0]->star->number); ?></div>
            </h5>
            <div id="collapse-2" class="collapse show" data-parent="#accordion">
                <div class="row">
                    <div class="col-6 font-weight-bold">من</div>
                    <div class="col-6 text-left"><?php echo e($date->items()[0]->star->from); ?></div>
                    <div class="col-6 font-weight-bold">المدة</div>
                    <div class="col-6 text-left"><?php echo e($date->items()[0]->star->duration); ?></div>
                </div>
            </div>
        </div>
        <div data-toggle="collapse" data-target="#collapse-2" class="shadow-sm p-3 mb-3 bg-white rounded">
            <h4 class="border-bottom pb-2">
                الطلع
                <div class="badge badge-primary float-left"><?php echo e($date->items()[0]->altala->number); ?></div>
            </h5>
            <div id="collapse-2" class="collapse show" data-parent="#accordion">
                <div class="row ">
                    <div class="col-6 font-weight-bold">من</div>
                    <div class="col-6 text-left"><?php echo e($date->items()[0]->altala->from); ?></div>
                    <div class="col-6 font-weight-bold">المدة</div>
                    <div class="col-6 text-left"><?php echo e($date->items()[0]->altala->duration); ?></div>
                </div>
            </div>
        </div>
        <div data-toggle="collapse" data-target="#collapse-2" class="shadow-sm p-3 mb-3 bg-white rounded">
            <h4 class="border-bottom pb-2">
                الفجر
                <div class="badge badge-primary float-left"><?php echo e($date->items()[0]->alfajr->number); ?></div>
            </h5>
            <div id="collapse-2" class="collapse show" data-parent="#accordion">
                <div class="row">
                    <div class="col-6 font-weight-bold">الشروق</div>
                    <div class="col-6 text-left"><?php echo e($date->items()[0]->alfajr->from); ?></div>
                    <div class="col-6 font-weight-bold">الغروب</div>
                    <div class="col-6 text-left"><?php echo e($date->items()[0]->alfajr->duration); ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="mt-5">
        <hr>
        <h3 class="py-2">الموضوعات</h3>
        <div class="text-white">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url('category',$category->id)); ?>" style="color: #fff;" class="d-block shadow-sm p-3 mb-3 bg-primary rounded"># <?php echo e($category->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/roznamah/resources/views/welcome.blade.php ENDPATH**/ ?>