<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AlFajr extends Model
{
    protected $fillable = ['number','from','duration'];
}
