<?php $__env->startSection('content'); ?>


<section dir="rtl">
	<div>
		<?php if(session('message')): ?>
			<div class="alert alert-success"> <?php echo e(session('message')); ?> </div>
		<?php endif; ?>
		<a href="<?php echo e(route('category.index')); ?> ">عوده</a>
		<?php if(isset($subcategory)): ?>
		<form method="post" action="<?php echo e(route('subcategory.update',$subcategory->id)); ?> ">
			<?php echo method_field('put'); ?>
			<h2 class="text-center">تعديل موضوع فرعى</h2>
		<?php else: ?>
		<form method="post" action="<?php echo e(route('subcategory.store')); ?> ">
			<h2 class="text-center">اضافه موضوع فرعى جديد</h2>
		<?php endif; ?>
			<?php echo csrf_field(); ?>
			<div style="margin: 25px 0px">
				<p>اسم الموضوع الفرعى</p>
				<input type="text" name="name" class="form-control" required <?= isset($subcategory) ? 'value="'.$subcategory->name.'"' : '' ?> >
				<p style="margin: 20px 0px 5px">الموضوع الرئيسى</p>
				<select class="form-control" name="category">
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($category->id); ?> " <?php if(isset($subcategory) && $subcategory->category->id == $category->id ){echo "selected";} ?> ><?php echo e($category->name); ?> </option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
				<p style="margin: 20px 0px 5px">المحتوى</p>
				<textarea id="editor" rows="10" name="content" class="form-control" ><?php echo e(isset($subcategory) ? $subcategory->content : ''); ?> </textarea>
				<button type="submit" class="btn btn-success" style="margin: 20px 0px 0px ">حفظ</button>
			</div>

		</form>
	</div>
</section>

<script src="https://cdn.ckeditor.com/ckeditor5/15.0.0/classic/ckeditor.js"></script>
<script>
	ClassicEditor
	.create( document.querySelector( '#editor' ) )
	.then( editor => {
		console.log( editor );
	} )
	.catch( error => {
		console.error( error );
	} );
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/roznamah/resources/views/admin/subcategory/form.blade.php ENDPATH**/ ?>