<?php $__env->startSection('content'); ?>


<h1>All The Dates</h1>
<a href="<?php echo e(route('day.create')); ?> " class="btn btn-primary">add new date</a>

<table class="table table-hover">
    <thead>
        <th>id</th>
        <th>day</th>
        <th>season</th>
        <th>al dor</th>
        <th>the star</th>
        <th>al dala</th>
        <th>al fajr</th>
    </thead>
    <tbody>
        <tr>
            <td>4</td>
            <td>438</td>
            <td>summer</td>
            <td>34</td>
            <td>34</td>
            <td>ere</td>
            <td>ere</td>
        </tr>
    </tbody>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/roznamah/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>