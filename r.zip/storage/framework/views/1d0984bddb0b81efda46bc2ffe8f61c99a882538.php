<?php $__env->startSection('content'); ?>

<section>
    <div class="block my-4" dir="rtl" >
        <div class="upper">
        	<h4 class="w-100 text-center" style="color: #fff"><?php echo e($subcategory->category->name ." => ". $subcategory->name); ?></h4>
        	<a href="<?php echo e(url('/category',$subcategory->category->id)); ?> " class="btn btn-light ml-4">العوده</a>
        </div>
        <div class="text-center p-3" style="font-size: 20px">
        	<?php echo $subcategory->content; ?>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/roznamah/resources/views/user/subcategory.blade.php ENDPATH**/ ?>