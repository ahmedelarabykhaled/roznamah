<?php $__env->startSection('content'); ?>

<style type="text/css">
	th,td
	{
		padding: 15px;
		text-align: center;
	}
</style>

<section dir="rtl">
	<div>
		<a href="<?php echo e(route('category.create')); ?> " class="btn btn-success">اضافه موضوع جديد</a>
		<a href="<?php echo e(route('subcategory.create')); ?> " class="btn btn-success">اضافه موضوع فرعى جديد</a>
		<h2 class="text-center">كل المواضيع</h2>
		<div>
			<table border="2px" style="width: 100%">
				<thead>
					<th style="width: 20px;">الرقم</th>
					<th>الموضوع</th>
					<th>الموضوعات الفرعيه</th>
					<th>خيارات</th>
				</thead>
				<tbody>
					<?php $count = 1; ?>
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($count++); ?></td>
						<td><?php echo e($category->name); ?></td>
						<td>
							<?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<ul style="text-align: right;" >
									<li>
										<?php echo e($subcategory->name); ?>

									</li>
							</ul>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</td>
						<td>
							<a href="<?php echo e(route('category.edit',$category->id)); ?>" style="color: #fc0">تعديل</a>
							<!-- Button trigger modal -->
							<a href="javascript:void(0)" style="color: #900" data-toggle="modal" data-target="#exampleModal">
							  حذف
							</a>

							<!-- Modal -->
							<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							  <div class="modal-dialog" role="document">
							    <div class="modal-content">
							      <div class="modal-header">
							        <h5 class="modal-title" id="exampleModalLabel">رساله تاكيد</h5>
							        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
							          <span aria-hidden="true">&times;</span>
							        </button>
							      </div>
							      <div class="modal-body">
							        هل تريد حذف هذا الموضوع ومعه كل المواضيع الفرعيه الخاصه به
							      </div>
							      <div class="modal-footer"> 
							        <button type="button" class="btn btn-secondary" data-dismiss="modal">الغاء</button>
							        <form style="display: inline-block;" method="post" action="<?php echo e(route('category.destroy',$category->id)); ?> ">
							        	<?php echo csrf_field(); ?>
							        	<?php echo method_field('delete'); ?>
							        	<button class="btn btn-danger">خذف</button>
							        </form>
							      </div>
							    </div>
							  </div>
							</div>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/roznamah/resources/views/admin/category/index.blade.php ENDPATH**/ ?>