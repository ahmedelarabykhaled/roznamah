<?php $__env->startSection('content'); ?>
<style type="text/css">
	a
	{
		color: #000;
	}
	a:hover
	{
		color: #000;
		text-decoration: underline;
	}
</style>
<section>
    <div class="block my-4" dir="rtl">
        <div class="upper">
        	<h4 class="w-100 text-center" style="color: #fff"><?php echo e($category->name); ?></h4>
        	<a href="<?php echo e(url('/')); ?> " class="btn btn-light ml-4">العوده</a>
        </div>
        <div class="text-center">
        	<?php if(sizeof($category->subcategories) == 0 ): ?>
        		<h2 class="p-5">لا يوجد مواضيع فرعيه لهذا الموضوع</h2>
        	<?php else: ?>
        		<table dir="rtl" border="2px" class="my-4 text-center w-75 mx-auto">
        			<tbody>
        				<?php
        					for ($i=0; $i < sizeof($category->subcategories); $i+=2) { 
        						?>
        							<tr>
        								<td>
        									<a href="<?php echo e(url('subcategory',$category->subcategories[$i]->id)); ?> ">
        										<?php echo e($category->subcategories[$i]->name); ?>

        									</a>
        								</td>
        								<?php
        									if ($i+1 < sizeof($category->subcategories)) {
        										?>
        											<td>
        												<a href="<?php echo e(url('subcategory',$category->subcategories[$i+1]->id)); ?>">
        													<?php echo e($category->subcategories[$i+1]->name); ?>

        												</a>
        											</td>
        										<?php
        									}
        								?>
        							</tr>
        						<?php
        					}
        				?>
        			</tbody>
        		</table>
        	<?php endif; ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/roznamah/resources/views/user/category.blade.php ENDPATH**/ ?>