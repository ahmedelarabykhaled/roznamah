<?php $__env->startSection('content'); ?>

<style type="text/css">
	table
	{
		min-width: 600px;
	}
	th,td
	{
		text-align: center !important;
		padding: 10px 4px;
	}
	tr:hover
	{
		background-color: #eee;
	}
	tr:nth-child(1):hover
	{
		background-color: #fff;
	}
	tr:nth-child(2):hover
	{
		background-color: #fff;
	}
</style>

<section dir="rtl">
	<?php if(session('message')): ?>
		<div class="alert alert-success"><?php echo e(session('message')); ?> </div>
	<?php endif; ?>
	<a href="<?php echo e(route('day.create')); ?> " class="btn btn-success">اضافه يوم جديد</a>
	<h2 class="text-center">كل الايام</h2>
	<div style="overflow-x: scroll;">
		<table style="width: 100%; margin-top: 10px;margin-bottom:10px ; font-size: 1em;" border="2px" class="mt-4">
		    <tbody>
		        <tr class="text-center" align="center" style="/* background-color: #344;*/color: #fff" >
		            <th rowspan="2">رقم اليوم</th>
		            <th colspan="2">التفاصيل</th>
		            <th rowspan="2">التاريخ</th>
		            <th rowspan="2">الفصل</th>
		            <th rowspan="2">الدر</th>
		            <th colspan="2">التفاصيل</th>
		            <th rowspan="2">النجم</th>
		            <th colspan="2">التفاصيل</th>
		            <th rowspan="2">الطلع</th>
		            <th colspan="2">التفاصيل</th>
		            <th rowspan="2">الفجر</th>
		            <th colspan="2">التفاصيل</th>
		            <th rowspan="2">خيارات</th>
		        </tr>
		        <tr style="/*background-color: #344;*/color: #fff">
		            <th>من</th>
		            <th>المده</th>
		            <th>من</th>
		            <th>المده</th>
		            <th>من</th>
		            <th>المده</th>
		            <th>من</th>
		            <th>المده</th>
		            <th>الشروق</th>
		            <th>الغروب</th>
		        </tr>
		        <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        	<tr>
		        		<td><?php echo e($date->day->number); ?> </td>
		        		<td><?php echo e($date->day->from); ?> </td>
		        		<td><?php echo e($date->day->duration); ?> </td>
		        		<td><?php echo e($date->date); ?> </td>
		        		<td><?php echo e($date->season); ?> </td>
		        		<td><?php echo e($date->aldor->number); ?> </td>
		        		<td><?php echo e($date->aldor->from); ?> </td>
		        		<td><?php echo e($date->aldor->duration); ?> </td>
		        		<td><?php echo e($date->star->number); ?> </td>
		        		<td><?php echo e($date->star->from); ?> </td>
		        		<td><?php echo e($date->star->duration); ?> </td>
		        		<td><?php echo e($date->altala->number); ?> </td>
		        		<td><?php echo e($date->altala->from); ?> </td>
		        		<td><?php echo e($date->altala->duration); ?> </td>
		        		<td><?php echo e($date->alfajr->number); ?> </td>
		        		<td><?php echo e($date->alfajr->from); ?> </td>
		        		<td><?php echo e($date->alfajr->duration); ?> </td>
		        		<td>
		        			<a href="<?php echo e(route('day.edit',$date->id)); ?>" style="color: #fc0" class="">تعديل</a>
		        			<!-- Button trigger modal -->
		        			<a href="javascript:void(0)" style="color: #900" class="d-inline" data-toggle="modal" data-target="#exampleModal">
		        			  حذف
		        			</a>

		        			<!-- Modal -->
		        			<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		        			  <div class="modal-dialog" role="document">
		        			    <div class="modal-content">
		        			      <div class="modal-header">
		        			        <h5 class="modal-title" id="exampleModalLabel">رساله تاكيد</h5>
		        			        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		        			          <span aria-hidden="true">&times;</span>
		        			        </button>
		        			      </div>
		        			      <div class="modal-body">
		        			        هل تريد حذف هذا اليوم
		        			      </div>
		        			      <div class="modal-footer">
		        			        <button type="button" class="btn btn-secondary" data-dismiss="modal">الغاء</button>
		        			        <form class="" style="display: inline" action="<?php echo e(route('day.destroy',$date->id)); ?> " method="post">
		        			        	<?php echo csrf_field(); ?>
		        			        	<?php echo method_field('delete'); ?>
		        			        	<button type="submit" class="btn btn-danger">حذف</button>
		        			        </form>
		        			      </div>
		        			    </div>
		        			  </div>
		        			</div>
		        		</td>
		        	</tr>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    </tbody>
		</table>
	</div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/roznamah/resources/views/admin/day/index.blade.php ENDPATH**/ ?>