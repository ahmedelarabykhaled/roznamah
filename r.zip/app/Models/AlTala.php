<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AlTala extends Model
{
    protected $fillable = ['number','from','duration'];
}
